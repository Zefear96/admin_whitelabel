import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import WatermarkEib from '../../components/layout/WatermarkEib';
import FormLoginEib from '../../components/dataEntry/formLogin/FormLoginEib';
import { Spin } from 'antd';



export default function LoginPage() {
  const { keycloak, initialized, authenticated } = useAuth();
  const navigate = useNavigate();
  const isRun = useRef(false);

  const [hasTriedLogin, setHasTriedLogin] = useState(false);

  useEffect(() => {
    if(!isRun.current) return;
    isRun.current = true;
    
    if (initialized) {
      if (authenticated) {
        console.log('User already authenticated, redirecting to home...');
        navigate('/', { replace: true });
      } else if (!hasTriedLogin) {
        console.log('User not authenticated, initiating login...');
        setHasTriedLogin(true);
        
        // Небольшая задержка чтобы избежать проблем с навигацией
        setTimeout(() => {
          keycloak.login({
            // Перенаправляем на главную страницу после логина, а не обратно на /login
            redirectUri: `${window.location.origin}/`
          });
        }, 100);
      }
    }
  }, [initialized, authenticated, navigate, keycloak, hasTriedLogin]);

  // Показываем загрузку пока Keycloak инициализируется
  if (!initialized) {
    return (
      <WatermarkEib>
        <div style={{
          textAlign: "center",
          position: "relative",
          zIndex: 10,
          height: "100vh",
          display: 'grid',
          placeItems: "center"
        }}>
          <Spin size="large" />
        </div>
      </WatermarkEib>
    );
  }

  // Показываем загрузку пока идет процесс логина
  if (!authenticated && hasTriedLogin) {
    return (
      <WatermarkEib>
        <div style={{
          textAlign: "center",
          position: "relative",
          zIndex: 10,
          height: "100vh",
          display: 'grid',
          placeItems: "center"
        }}>
          <div>
            <Spin size="large" />
            <p style={{ marginTop: 16 }}>Перенаправление на страницу входа...</p>
          </div>
        </div>
      </WatermarkEib>
    );
  }

  return (
    <WatermarkEib>
      <div style={{
        textAlign: "center",
        position: "relative",
        zIndex: 10,
        height: "100vh",
        display: 'grid',
        placeItems: "center"
      }}>
        <FormLoginEib />
      </div>
    </WatermarkEib>
  )
}