import { UserOutlined, PieChartOutlined, SettingOutlined } from '@ant-design/icons';
import type { Section } from '../types/sections';

export const sections: Section[] = [
   {
    key: 'sub1',
    label: 'Управление доступами',
    // icon: <MailOutlined />,
    roles: ['admin', 'manager'],
    children: [
      { key: '1', label: 'Роли', roles: ['admin', 'manager'] },
      { key: '2', label: 'Привилегии', roles: ['admin', 'manager'] },
      { key: '3', label: 'Профили', roles: ['admin', 'manager'] },
    ],
  },
  {
    key: 'sub2',
    label: 'Настройка лимитов',
    // icon: <AppstoreOutlined />,
    roles: ['admin', 'analyst'],
    children: [
      { key: '4', label: 'Юр.лица', roles: ['admin', 'manager'] },
      { key: '5', label: 'ИП', roles: ['admin', 'manager'] },
      { key: '6', label: 'Физ.лица', roles: ['admin', 'manager'] },
      { key: '7', label: 'Онлайн', roles: ['admin', 'manager'] },
    ],
  },
  {
    key: 'sub3',
    label: 'Комплаенс',
    // icon: <AppstoreOutlined />,
    roles: ['admin', 'analyst'],
    children: [
      { key: '8', label: 'Клиенты', roles: ['admin', 'manager'] },
      { key: '9', label: 'Операции', roles: ['admin', 'manager'] },
      { key: '10', label: 'Блэклист', roles: ['admin', 'manager'] },
      { key: '11', label: 'Антифрод', roles: ['admin', 'manager'] },
    ],
  },
  {
    key: 'sub4',
    label: 'Аналитика',
    // icon: <AppstoreOutlined />,
    roles: ['admin', 'analyst'],
    children: [
      { key: '12', label: 'Метрики', roles: ['admin', 'analyst'] },
      {
        key: '13',
        label: 'Документация',
        roles: ['admin'],
        children: [
          { key: '31', label: 'Дашборды', roles: ['admin'] },
          { key: '32', label: 'Отчёты', roles: ['admin'] },
          { key: '33', label: 'Акты', roles: ['admin'] },
        ],
      },
      { key: '14', label: 'Мониторинг', roles: ['admin', 'analyst'] },
    ],
  },
  {
    key: 'sub5',
    label: 'Сервис деск',
    // icon: <SettingOutlined />,
    roles: ['admin','service-desk'],
    children: [
      { key: '15', label: 'Клиенты', roles: ['admin','service-desk'] },
      { key: '16', label: 'Заявки', roles: ['admin','service-desk'] },
    ],
  },
  {
    key: 'sub6',
    label: 'Администрирование',
    // icon: <AppstoreOutlined />,
    roles: ['admin', 'analyst'],
    children: [
      { key: '17', 
        label: 'Настройка клиентов', 
        roles: ['admin', 'analyst'],
        children: [
          { key: '18', label: 'Юр.лица', roles: ['admin'] },
          { key: '19', label: 'Физ.лица', roles: ['admin'] },
        ] 
      },
      {
        key: '20',
        label: 'Настройка продуктов',
        roles: ['admin'],
        children: [
          { key: '21', label: 'Счета', roles: ['admin'] },
          { key: '22', label: 'Карты', roles: ['admin'] },
          { key: '23', label: 'Мудараба', roles: ['admin'] },
          { key: '24', label: 'Мурабаха', roles: ['admin'] },
          { key: '25', label: 'Сейфовые ячейки', roles: ['admin'] },
        ],
      },
      { key: '26', label: 'Настройка оповещений', roles: ['admin', 'analyst'] },
      { key: '27', label: 'Настройка сервисов', roles: ['admin', 'analyst'] },
      { key: '28', label: 'Настройка тарифов', roles: ['admin', 'analyst'] },
    ],
  },
  {
    key: 'sub7',
    label: 'Маркетинг',
    // icon: <SettingOutlined />,
    roles: ['admin','marketing'],
    children: [
      { key: '29', label: 'Акции', roles: ['admin','marketing'] },
      { key: '30', label: 'Баннеры', roles: ['admin','marketing'] },
    ],
  },
];
