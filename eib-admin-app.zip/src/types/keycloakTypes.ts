// src/config/types.ts
export interface KeycloakTypes {
    keycloakUrl: string;
    keycloakRealm: string;
    keycloakClientId: string;
    keycloakPkce: string;
  }
  