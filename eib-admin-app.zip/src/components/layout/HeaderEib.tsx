import React from 'react';
import { Avatar, Badge, Popover, Switch } from 'antd';
import { Header } from 'antd/es/layout/layout';
import { useAuth } from '../../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import DrawerEib from './DrawerEib';
import { useTheme } from '../../hooks/useTheme';
import SwitchThemeEib from '../dataEntry/SwitchThemeEib';
import { BellOutlined } from '@ant-design/icons';
import PopoverNotif from '../dataDisplay/PopoverNotif';

export default function HeaderEib() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { mode, colors, toggleTheme } = useTheme();

  return (
    <Header style={{
      backgroundColor: '#f5f5f5',
      // borderBottom: `1px solid ${colors.surface}`
    }}>
      <div style={{
        display: "flex",
        justifyContent: "end",
        alignItems: "center",
        height: '100%'
      }}>
        {/* <Popover
          content={<PopoverNotif />}
          trigger="click"
          placement='bottomRight'>
          <a href="#"
            style={{
              margin: "auto 20px",
              display: "flex",
              alignItems: "center",
            }}>
            <Badge count={5} color={colors.primary}
              style={{
                fontSize: 14
              }}>
              <BellOutlined style={{
                color: colors.primary,
              }}
                height={34}
                width={34} />
            </Badge>
          </a>
        </Popover> */}
        <PopoverNotif/>
        <DrawerEib />
      </div>
    </Header>
  );
}