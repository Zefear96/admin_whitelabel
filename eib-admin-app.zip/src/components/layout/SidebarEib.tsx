import { useEffect, useState } from 'react';
import { Button, Divider, Menu, Skeleton, Switch } from 'antd';
import eibIcon from '../../assets/eib-icon.svg';
import { useAuth } from '../../hooks/useAuth';
import { mapSectionsToMenuItems } from '../../utils/mapSectionsToMenu';
import { useTheme } from '../../hooks/useTheme';
import { fetchMenuSections } from '../../services/fetchMenuSections';
import { filterEnabledSections } from '../../utils/filterEnabledSections';
import type { MenuProps } from 'antd';
import SwitchModeEib from '../dataEntry/SwitchModeEib';
import SwitchThemeEib from '../dataEntry/SwitchThemeEib';
import MenuItem from 'antd/es/menu/MenuItem';
import ButtonLogout from '../dataEntry/ButtonLogout';
import { Option } from 'antd/es/mentions';

export default function SidebarEib() {
  const { user, logout } = useAuth();
  const { colors, mode, spacing, menuMode } = useTheme();
  const [current, setCurrent] = useState('1');
  const [items, setItems] = useState<MenuProps['items']>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadMenu = async () => {
      try {
        const serverSections = await fetchMenuSections();
        const allowedSections = filterEnabledSections(serverSections);
        const mapped = mapSectionsToMenuItems(allowedSections);
        setItems(mapped);
        // setLoading(false);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadMenu();
  }, [user]);

  if (loading) return (
    <Skeleton
      active
      style={{
        margin: spacing(2),
        background: colors.surface,
        padding: spacing(2)
      }}
    />
  );

  const siderStyle: React.CSSProperties = {
    overflow: 'auto',
    height: '100vh',
    position: 'sticky',
    insetInlineStart: 0,
    top: 0,
    bottom: 0,
    scrollbarWidth: 'thin',
    scrollbarGutter: 'stable',
    backgroundColor: colors.background,
    color: colors.text,
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      color: colors.text,
      backgroundColor: colors.background,
    }}>
      <div style={{
        display: "flex",
        alignItems: "center",
        padding: "5px",
        justifyContent: "space-between"
      }}>
        <img src={eibIcon} alt="EIB Logo"
          style={{
            width: '48px',
            height: '48px',
            margin: "10px"
          }} />
        <p style={{
          color: "#408CA5",
          fontWeight: "600",
          fontSize: "24px"
        }}>EcoIslamic</p>
      </div>
      <div style={{
        width: "60%",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}>
      </div>
      <Menu
        // style={{
        //   color: colors.text,
        //   backgroundColor: colors.background,
        //   height: "100vh",
        //   position: 'sticky',
        //   fontWeight: "600"

        // }}
        // style={siderStyle}
        // defaultSelectedKeys={['1']}
        // defaultOpenKeys={['sub1']}
        style={{
          marginTop: "20px",
          border: "none",
          background: colors.background,
          color: colors.text
        }}
        mode={menuMode}
        items={items}
        theme={mode}
        key={mode} // Force re-render on theme change
        // selectedKeys={[location.pathname]}
      />
      <Divider style={{ borderColor: colors.surface }} />
      <Button onClick={logout}
        type="text" block
        style={{
          height: "40px",
          color: colors.text,
          width: "calc(100% - 8px)",
          paddingLeft: "24px",
          margin: "4px",
          borderRadius: "8px",
          justifyContent: "start"
        }}>Выйти</Button>
    </div>
  );
}